function [window,HCenter,VCenter,slack]=creat_mainWin

%% parameters of window
    AssertOpenGL;
    scrnNum =max(Screen('Screens'));
    background=125;

%% open the main window
    [window,windowRect]=Screen('OpenWindow',scrnNum,background);
    slack=Screen('GetFlipInterval',window)/2;  %to estimate the monitor flip interval for the window
    HRes=windowRect(3);VRes=windowRect(4);% resollution 1024*768. The whole Rect[0 0 1024 768]
    HCenter=round(HRes/2);
    VCenter=round(VRes/2);

    Screen('TextFont',window, 'Arial');
    Screen('TextSize',window, 40);
    
    %set up alpha-blending for smooth (anti-aliased) lines
    Screen('BlendFunction',window,'GL_SRC_ALPHA','GL_ONE_MINUS_SRC_ALPHA');