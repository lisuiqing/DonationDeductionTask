function pracDonate(name,ID,gender)
% gender: 1 = male; 2 = female;
% EXAMPLE: pracDonate('luoyi',101,2)

%% 1 clean up comand windows and set the current path
clc
path=pwd;
Screen('Close');
%Priority(0)


%% 2. data collecting: open an .txt file here.
abc=fix(clock);
if gender==1
    fidraw=fopen([path '\Data\pracDonate_' num2str(name) '_' num2str(ID) '_' num2str(abc(4)) '_' num2str(abc(5)) '_Male.txt'],'a');
elseif gender==2
    fidraw=fopen([path '\Data\pracDonate_' num2str(name) '_' num2str(ID) '_' num2str(abc(4)) '_' num2str(abc(5)) '_Female.txt'],'a');
end

fprintf(fidraw,'Date \t Name \t ID \t Gender \t Trial \t name_of_child1 \t name_of_child2a \t name_of_child2b \t start_onset \t offer_to_child1 \t offer_to_child2a \t offer_to_child2b  \t option_onset \t outcome_of_child1 \t outcome_of_child2a \t outcome_of_child2b \t RT \t Decisions \t \n');

%% 3. open a main window: our stimuli will be presented in this main window (for the whole of the experiment)
HideCursor;
[window,HCenter,VCenter,slack]=creat_mainWin; %employ the function of "creat_mainWin" here.



%% 4. initilizing experimental parameters (the sequence of trials)

trialnum=2;

%list the names for the children

name_allchild={'�޼�','������','Ф����','������','���� ','������','����','����','������','��ĺ��',...
     '����Դ','���ı�','л��־','������','����ǰ','���Ĳ�','��־��','̷��־','��˹��','������',...
     '������','����','�μ���','Ф��','������','���ʴ�','���','��ʤ','��ܷ�','���',...
     '����Դ','����','���濡','������','̷����','¬ӱ','�ź���','����','����','����ӳ',...
     '���־','����','����','�����','��ܿ','������','������','������','���� ','���˼',...
     '��ï��','�޼�','�޾�','�޺컨','Ԭ���','�����','������','�޶���','������','Ф��'};
 
 %randomize the names
 perm=randperm(length(name_allchild));
 name_allchild=name_allchild(perm);
 
 % get the name list for child1, child2a, and child2b
 child1_id=name_allchild(1:18);
 child2a_id=name_allchild(21:38);
 child2b_id=name_allchild(41:58);
 
final_id(1,:)=[-23 -23 -23 -23 -23 -23 -19 -19 -19 -19 -19 -19 -15 -15 -15 -15 -15 -15]; %offers to child1
final_id(2,:)=[-13 -21 -12 -21 -12 -20 -11 -17 -10 -17 -10 -16 -9 -13 -8 -13 -8 -12]; %offers to child2a
final_id(3,:)=[-13 -5 -12 -3 -11 -3 -11 -5 -10 -3 -9 -3 -9 -5 -8 -3 -7 -3]; %offers to child2b

final_id=final_id(:,randperm(trialnum));   %randomize conditions

%setting up RT and decisions.

RT=zeros(1,trialnum);
dec=zeros(1,trialnum);


%setting up start keys.
startK=KbName('s');
startK2=KbName('S');


%setting up durations
context_dur=2;
outcome_dur=2;
blank_dur=2+rand(1,trialnum);

%% 5. setting up windows

%what's in the final_id: 1-offer to child1; 2-offer to child2a; 3-offer to child2b

%blank screen
 blank_img=imread([path '\Pic\blank.jpg'],'jpg');
 blank_win=Screen('MakeTexture',window,blank_img);

% instruments
instruct_img=imread([path '\Pic\prac_instruct.jpg'],'jpg');
instruct_win=Screen('MakeTexture',window,instruct_img);


%option screen
% arrow pointing to the left
option1_img=imread([path '\Pic\option1.jpg'],'jpg');
option1_win=Screen('MakeTexture',window,option1_img);
% arrow pointing to the right
option2_img=imread([path '\Pic\option2.jpg'],'jpg');
option2_win=Screen('MakeTexture',window,option2_img);

%response images
for r = 1:2 % choose enter or shift
    response_img{r}=imread([path '\Pic\choose_',num2str(r),'.jpg'],'jpg');
    response_win{r}=Screen('MakeTexture',window,response_img{r});
end

outcome_img=imread([path '\Pic\feedback.jpg'],'jpg'); %instruction images
outcome_win=Screen('MakeTexture',window,outcome_img);


%buttons
enterK=KbName('Return'); 
shiftK=KbName('right_shift');


%% 6. positions, etc


% position of blank screen
[hig,wid,x]=size(blank_img);
blank_pos=[HCenter-wid/2 VCenter-hig/2 HCenter+wid/2 VCenter+hig/2];


% position of options
[hig,wid,x]=size(option1_img);
option_pos=[HCenter-wid/2 VCenter-hig/2 HCenter+wid/2 VCenter+hig/2];


%position of responses
[hig,wid,x]=size(response_img{1});
response_pos=[HCenter-wid/2 VCenter-hig/2 HCenter+wid/2 VCenter+hig/2];

%position of feedback
[hig,wid,x]=size(outcome_img);
outcome_pos=[HCenter-wid/2 VCenter-hig/2 HCenter+wid/2 VCenter+hig/2];


%% fixation
len=30; %length of the fixatoin
fixs.pos=[-len len 0 0;0 0 -len len];
fixs.wid=4; %width of the fixation
fixs.center=[HCenter, VCenter];
fixs.color=[255 255 255];

%% 7. ready window%%%

%present instructions
Screen('DrawTexture',window,instruct_win);
Screen('Flip',window);
while 1
    [keyIsDown,secs,keyCode]=KbCheck;
    if keyCode(startK)||keyCode(startK2)
        break;
    end
end

%start fixation.
Screen('DrawLines',window,fixs.pos,fixs.wid,fixs.color,fixs.center,2);
t=GetSecs;
Screen('Flip',window,t-slack);%fixation window
t=GetSecs+3;
Screen('Flip',window,t-slack);%fixation window


%% 8. loop for each trial. Need "present_UG" here.

t=GetSecs; %This is when experiments begins


for i=1:trialnum
    name_child1=double(child1_id{i});
    name_child2a=double(child2a_id{i});
    name_child2b=double(child2b_id{i});
    
     if rand(1)>0.5% random the position of the two groups of childern, there are 50% chance child2a and child2b are on the left.
         [child_mu(:,i),start_onset(i),option_onset(i),RT(i),dec(i),t]=present_Donate_1(name_child1,name_child2a,name_child2b,blank_dur(i),context_dur,outcome_dur,window,slack,final_id(:,i),enterK,shiftK,blank_pos,option_pos,response_pos,outcome_pos,blank_win,option1_win,response_win,outcome_win,t,HCenter,VCenter); % 
     else%there are 50% chance child2a and child2b are on the right.
         [child_mu(:,i),start_onset(i),option_onset(i),RT(i),dec(i),t]=present_Donate_2(name_child1,name_child2a,name_child2b,blank_dur(i),context_dur,outcome_dur,window,slack,final_id(:,i),enterK,shiftK,blank_pos,option_pos,response_pos,outcome_pos,blank_win,option2_win,response_win,outcome_win,t,HCenter,VCenter); % 
     end
end

%% 9. collecting data for each run

%what's in the final_id: 1-offer to child1; 2-offer to child2a; 3-offer to child2b

for i=1:trialnum
    fprintf(fidraw,'%s\t',date);
    fprintf(fidraw,'%s\t',name);
    fprintf(fidraw,'%3d\t',ID);
    fprintf(fidraw,'%3d\t',gender);
    fprintf(fidraw,'%3d\t',i);  %trial number
    fprintf(fidraw,'%s\t',child1_id{i});%name of child1
    fprintf(fidraw,'%s\t',child2a_id{i});%name of child2a
    fprintf(fidraw,'%s\t',child2b_id{i});%name of child2b
    fprintf(fidraw,'%6.3f\t',start_onset(i));  %onset of the start of a trial
    fprintf(fidraw,'%2d\t',final_id(1,i)); % offer to child1
    fprintf(fidraw,'%2d\t',final_id(2,i)); % offer to child2a
    fprintf(fidraw,'%2d\t',final_id(3,i)); % offer to child2b
    fprintf(fidraw,'%6.3f\t',option_onset(i));  %onset for the options showing up
    fprintf(fidraw,'%2d\t',child_mu(1,i)); % outcome-offer to child1    
    fprintf(fidraw,'%2d\t',child_mu(2,i)); % outcome-offer to child2a
    fprintf(fidraw,'%2d\t',child_mu(3,i)); % outcome-offer to child2b
    fprintf(fidraw,'%6.3f\t',RT(i));  %RT
    fprintf(fidraw,'%2d\t',dec(i)); %1=enter; 2=shift
    
    fprintf(fidraw,'\n');
end

%final fixation.
Screen('DrawLines',window,fixs.pos,fixs.wid,fixs.color,fixs.center,2);
t=GetSecs+2;
Screen('Flip',window,t-slack);%fixation window
t=GetSecs+3;
Screen('Flip',window,t-slack);%fixation window


%% clear all stuff after each run
Screen ('CloseAll');  %must use this one to get rid of syn problems.
status=fclose(fidraw);
clear all;