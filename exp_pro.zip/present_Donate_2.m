function[child_mu,start_onset,option_onset,RT,dec,t]=present_Donate_2(name_child1,name_child2a,name_child2b,blank_dur,context_dur,outcome_dur,window,slack,final_id,enterK,shiftK,blank_pos,option_pos,response_pos,outcome_pos,blank_win,option2_win,response_win,outcome_win,t,HCenter,VCenter)

% --------------------------set-up for markers--------------------------
 config_io;
 address = hex2dec('378');
% -----------------------------------------------------------------------


%1. blank screen
Screen('DrawTexture',window,blank_win,[],blank_pos);
Screen('Flip',window,t-slack);

% --------------mark the start of a trial as 7--------------------------
 outp(address,7);
% -----------------------------------------------------------------------

start_onset=t;
t=t+blank_dur; 

%2. options

%text positions (one children on the left; two on the right)
option_texts.pos1=[HCenter-360, VCenter-150];% names in the options
option_texts.pos2=[HCenter+130, VCenter-150];
option_texts.pos3=[HCenter+320, VCenter-150];

option_number.pos1=[HCenter-340, VCenter-50];% money units in the options
option_number.pos2=[HCenter+160, VCenter-50];
option_number.pos3=[HCenter+350, VCenter-50];

outcome_texts.pos1=[HCenter-200, VCenter-120];% names in the feedback
outcome_texts.pos2=[HCenter-200, VCenter+40];
outcome_texts.pos3=[HCenter-200, VCenter+200];

outcome_number.pos1=[HCenter+40, VCenter-120];% money units in the feedback
outcome_number.pos2=[HCenter+40, VCenter+40];
outcome_number.pos3=[HCenter+40, VCenter+200];

% draw the text and images of the option screen
Screen('DrawTexture',window,option2_win,[],option_pos); % option settings
Screen('DrawText',window,name_child1,option_texts.pos1(1),option_texts.pos1(2),[255,255,255]);  %name of child1
Screen('DrawText',window,name_child2a,option_texts.pos2(1),option_texts.pos2(2),[255,255,255]);  %name of child2a
Screen('DrawText',window,name_child2b,option_texts.pos3(1),option_texts.pos3(2),[255,255,255]);  %name of child2b
Screen('DrawText',window,num2str(final_id(1)),option_number.pos1(1),option_number.pos1(2),[255,255,255]);  %money units of child1
Screen('DrawText',window,num2str(final_id(2)),option_number.pos2(1),option_number.pos2(2),[255,255,255]);  %money units of child2a
Screen('DrawText',window,num2str(final_id(3)),option_number.pos3(1),option_number.pos3(2),[255,255,255]);  %money units of child2b

rons_rate=Screen('Flip',window,t-slack);
option_onset=t;

% --------------mark the option-presented as 8---------------------------
 outp(address,8);
% -----------------------------------------------------------------------

RT=0;
dec=0;

while 1 
    [keyIsDown,secs,keyCode]=KbCheck;

    if keyCode(enterK)
        RT=secs-rons_rate;
        dec=1;
        
        break;
    end

    if keyCode(shiftK)
        RT=secs-rons_rate;
        dec=2;
        break;
    end
end

t=GetSecs;

%3. response screen
if  keyCode(shiftK)
    Screen('DrawTexture',window,response_win{1},[],response_pos); % response settings
    Screen('DrawText',window,name_child1,option_texts.pos1(1),option_texts.pos1(2),[255,255,255]);  %name of child1
    Screen('DrawText',window,name_child2a,option_texts.pos2(1),option_texts.pos2(2),[255,255,255]);  %name of child2a
    Screen('DrawText',window,name_child2b,option_texts.pos3(1),option_texts.pos3(2),[255,255,255]);  %name of child2b
    Screen('DrawText',window,num2str(final_id(1)),option_number.pos1(1),option_number.pos1(2),[255,255,255]);  %money units of child1
    Screen('DrawText',window,num2str(final_id(2)),option_number.pos2(1),option_number.pos2(2),[255,255,255]);  %money units of child2a
    Screen('DrawText',window,num2str(final_id(3)),option_number.pos3(1),option_number.pos3(2),[255,255,255]);  %money units of child2b
    Screen('Flip',window,t-slack);
    
    child1_mu=num2str(final_id(1));
    child2a_mu=num2str(0);
    child2b_mu=num2str(0);
    
elseif keyCode(enterK)
    Screen('DrawTexture',window,response_win{2},[],response_pos); % response settings
    Screen('DrawText',window,name_child1,option_texts.pos1(1),option_texts.pos1(2),[255,255,255]);  %name of child1
    Screen('DrawText',window,name_child2a,option_texts.pos2(1),option_texts.pos2(2),[255,255,255]);  %name of child2a
        Screen('DrawText',window,name_child2b,option_texts.pos3(1),option_texts.pos3(2),[255,255,255]);  %name of child2b
    Screen('DrawText',window,num2str(final_id(1)),option_number.pos1(1),option_number.pos1(2),[255,255,255]);  %money units of child1
    Screen('DrawText',window,num2str(final_id(2)),option_number.pos2(1),option_number.pos2(2),[255,255,255]);  %money units of child2a
    Screen('DrawText',window,num2str(final_id(3)),option_number.pos3(1),option_number.pos3(2),[255,255,255]);  %money units of child2b
    Screen('Flip',window,t-slack);
    
    child1_mu=num2str(0);
    child2a_mu=num2str(final_id(2));
    child2b_mu=num2str(final_id(3));
    
end

t=t+context_dur;

%4. outcome

Screen('DrawTexture',window,outcome_win,[],outcome_pos); % outcome of the current trial.
Screen('DrawText',window,name_child1,outcome_texts.pos1(1),outcome_texts.pos1(2),[255,255,255]);  %name of child1
Screen('DrawText',window,name_child2a,outcome_texts.pos2(1),outcome_texts.pos2(2),[255,255,255]);  %name of child2a
Screen('DrawText',window,name_child2b,outcome_texts.pos3(1),outcome_texts.pos3(2),[255,255,255]);  %name of child2b
Screen('DrawText',window,child1_mu,outcome_number.pos1(1),outcome_number.pos1(2),[255,255,255]);  %money units of child1
Screen('DrawText',window,child2a_mu,outcome_number.pos2(1),outcome_number.pos2(2),[255,255,255]);  %money units of child2a
Screen('DrawText',window,child2b_mu,outcome_number.pos3(1),outcome_number.pos3(2),[255,255,255]);  %money units of child2b
Screen('Flip',window,t-slack);

t=t+outcome_dur;

child_mu=[str2num(child1_mu);str2num(child2a_mu);str2num(child2b_mu)];