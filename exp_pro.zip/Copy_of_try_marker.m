%config_io;

% for i=1:100
%     config_io;
%     address = hex2dec('c020');
%     byte = 1;
%     outp(address,byte);
%     pause(0.1);
% %     outp(address,0);
% %     pause(0.2);
% end
% 
% for i=1:100
%     config_io;
%     address = 378;
%     byte = 1;
%     outp(address,byte);
%     pause(0.1);
% %     outp(address,0);
% %     pause(0.2);
% end
x=[1 2 1 2 1 2 1 2 1 2];

for i=1:10
    config_io;
    address = hex2dec('378');
    byte = num2str(x(i));
    outp(address,byte);
    pause(3);
%     outp(address,0);
%     pause(0.2);
end

% 
% for i=1:100
%     config_io;
%     address = 'c020';
%     byte = 7;
%     outp(address,byte);
%     pause(0.2);
%     outp(address,0);
%     pause(0.2);
% end
% 
% 
% 
% for i=1:100
%     config_io;
%     address = hex2dec('c010');
%     byte = 7;
%     outp(address,byte);
%     pause(0.02);
%     outp(address,0);
%     pause(0.02);
% end
% 
% 
% 
% for i=1:100
%     config_io;
%     address = 'c010';
%     byte = 7;
%     outp(address,byte);
%     pause(0.02);
%     outp(address,0);
%     pause(0.02);
% end
